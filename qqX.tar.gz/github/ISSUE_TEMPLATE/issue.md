---
name: Issue
about: 'Bug report  -  qqX specific '
title: 'Bug report  -  qqX specific '
labels: ''
assignees: ''

---

Standard  elimination and substitution methods should be used prior to posting: 

Does it happen to all VM's  & does it happen when you try directly with quickemu itself?  

Have you tried different Virtual Machines.  If it only happens  to one VM then re-install the machine or try creating another version on your main host or on another, if you have one.

Did the problems start when Quickemu or Qemu updated?   Have you tried the reverting back to an older version.?  Notes are in the qqX general settings file ...

Problems with quickemu or quickget should be submitted at https://github.com/quickemu-project/quickemu  Qemu at https://gitlab.com/qemu-project/qemu/-/issues

For advice and discussion try the quickemu  forum at https://discord.gg/sNmz3uw

### General Description:

Host OS ,  qqX, quickemu &  Qemu versions:

### Screenshots & Error messages:

### Description of tests conducted and results:
